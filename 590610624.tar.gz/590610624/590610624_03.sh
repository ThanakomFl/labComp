#!/bin/bash

mkdir $1/html $1/css $1/js
find $1/ -name "*.html" | wc -l > html.txt
find $1/ -name "*.css" | wc -l > css.txt
find $1/ -name "*.js" | wc -l > js.txt
for f in `find $1/ -name "*.html"`
do
	mv $f $1/html
done
for f in `find $1/ -name "*.css"`
do
	mv $f $1/css
done
for f in `find $1/ -name "*.js"`
do
	mv $f $1/js
done

a=`cat html.txt`
b=`cat css.txt`
c=`cat js.txt`
echo "<html>" | cat > index.html
echo "<head>" | cat >> index.html
echo "</head>" | cat >> index.html
echo "<body>" | cat >> index.html
echo "<table border = 1 >" | cat >> index.html
echo "<tr bgcolor = lightgray > " | cat >> index.html
echo "	<td><center> File Type </center></td> " | cat >> index.html
echo "	<td><center> Quantity </center></td> " | cat >> index.html
echo " </tr> " | cat >> index.html
echo " <tr>  " | cat >> index.html
echo "	<td><center> html </center></td> " | cat >> index.html
echo "	<td><center>  $a </center></td>  " | cat >> index.html
echo " </tr> " | cat >> index.html
echo " <tr> " | cat >> index.html 
echo " <td><center> css </center></td> " | cat >> index.html
echo " 	<td><center> $b </center></td> " | cat >> index.html
echo "</tr>" | cat >> index.html
echo "<tr>" | cat >> index.html 
echo "	<td><center> js </center></td> " | cat >> index.html
echo "	<td><center> $c </center></td> " | cat >> index.html
echo "</tr>" | cat >> index.html
echo "<tr>  " | cat >> index.html
echo "	<td><center> Total </center></td> " | cat >> index.html
echo "	<td><center> `expr $a + $b + $c ` </center></td> " | cat >> index.html
echo " </tr> " | cat >> index.html
echo " </table> " | cat >> index.html

echo " </center> " | cat >> index.html
echo "</body> " | cat >> index.html
echo " </html> " | cat >> index.html

rm css.txt html.txt js.txt
mv index.html 590610624File.html
